# ChiragRanks (kits edition)

Kits plugin for Paper 1.21+ (Java 21). Ranks are handled by LuckPerms.

- Starter kit: everyone (permission `chiragranks.kit.starter`, default true).
- All other kits: players in LuckPerms groups listed in `config.yml > kits.staff-groups` (owner, co-owner, co_owner, admin),
  or anyone you give `chiragranks.kit.<vip|mvp|legendary|media|elite|cosmic>`.
- Staff groups ignore cooldowns and can use `/kit reset` and `/kit reload`.

Commands: `/kit`, `/kit <name>`, `/kit preview <name>`, `/kit list`, `/kit reset <player> <kit|all>`, `/kit reload`
