package com.chirag.chiragranks.gui;

import com.chirag.chiragranks.ChiragRanks;
import com.chirag.chiragranks.kits.Kit;
import com.chirag.chiragranks.kits.KitManager;
import com.chirag.chiragranks.utils.Messages;
import com.chirag.chiragranks.utils.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Builds and refreshes the kit menu and the kit preview menu. */
public final class KitGUI {

    /** Holder for the main kit menu. */
    public static final class MainHolder implements InventoryHolder {
        private Inventory inventory;
        private final Map<Integer, String> kitSlots = new HashMap<>();
        private int closeSlot = -1;

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        public Map<Integer, String> kitSlots() {
            return kitSlots;
        }

        public int closeSlot() {
            return closeSlot;
        }
    }

    /** Holder for the kit preview menu. */
    public static final class PreviewHolder implements InventoryHolder {
        private Inventory inventory;
        private final String kitId;
        private int backSlot = -1;

        public PreviewHolder(String kitId) {
            this.kitId = kitId;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        public String kitId() {
            return kitId;
        }

        public int backSlot() {
            return backSlot;
        }
    }

    private final ChiragRanks plugin;

    public KitGUI(ChiragRanks plugin) {
        this.plugin = plugin;
    }

    public void openMain(Player player) {
        FileConfiguration config = plugin.getConfig();
        int rows = Math.max(3, Math.min(6, config.getInt("gui.rows", 5)));
        MainHolder holder = new MainHolder();
        Inventory inventory = Bukkit.createInventory(holder, rows * 9,
                Text.parse(config.getString("gui.title", "<gold>✦ RANK KITS ✦")));
        holder.inventory = inventory;
        populate(player, holder);
        player.openInventory(inventory);
    }

    /** (Re)fills the main menu for the given player. */
    public void populate(Player player, MainHolder holder) {
        Inventory inventory = holder.inventory;
        inventory.clear();
        holder.kitSlots.clear();
        int size = inventory.getSize();

        // Reserve the close slot first.
        int closeSlot = size - 5;
        inventory.setItem(closeSlot, button("gui.close-material", Material.BARRIER, "gui-close"));
        holder.closeSlot = closeSlot;

        for (Kit kit : plugin.kits().getKits()) {
            int slot = kit.slot();
            if (slot < 0 || slot >= size - 9 || inventory.getItem(slot) != null) {
                slot = nextFreeSlot(inventory);
            }
            if (slot < 0) {
                continue;
            }
            inventory.setItem(slot, kitIcon(player, kit));
            holder.kitSlots.put(slot, kit.id());
        }

        ItemStack filler = filler();
        for (int i = 0; i < size; i++) {
            if (inventory.getItem(i) == null) {
                inventory.setItem(i, filler.clone());
            }
        }
    }

    public void openPreview(Player player, Kit kit) {
        FileConfiguration config = plugin.getConfig();
        PreviewHolder holder = new PreviewHolder(kit.id());
        int count = Math.min(kit.items().size(), 45);
        int rows = Math.min(6, (count + 8) / 9 + 1);
        Inventory inventory = Bukkit.createInventory(holder, rows * 9,
                Text.parse(config.getString("gui.preview-title", "<kit>"),
                        Placeholder.component("kit", kit.displayComponent())));
        holder.inventory = inventory;
        for (int i = 0; i < count; i++) {
            inventory.setItem(i, kit.items().get(i).clone());
        }
        int backSlot = inventory.getSize() - 5;
        inventory.setItem(backSlot, button("gui.back-material", Material.ARROW, "gui-back"));
        holder.backSlot = backSlot;
        ItemStack filler = filler();
        for (int i = count; i < inventory.getSize(); i++) {
            if (inventory.getItem(i) == null) {
                inventory.setItem(i, filler.clone());
            }
        }
        player.openInventory(inventory);
    }

    private int nextFreeSlot(Inventory inventory) {
        for (int i = 9; i < inventory.getSize() - 9; i++) {
            if (inventory.getItem(i) == null) {
                return i;
            }
        }
        return -1;
    }

    private ItemStack filler() {
        Material material = material(plugin.getConfig().getString("gui.filler-material"), Material.BLACK_STAINED_GLASS_PANE);
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Component.text(" "));
        meta.addItemFlags(ItemFlag.values());
        stack.setItemMeta(meta);
        return stack;
    }

    private ItemStack button(String configKey, Material fallback, String messageKey) {
        Material material = material(plugin.getConfig().getString(configKey), fallback);
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(plugin.messages().item(messageKey));
        meta.addItemFlags(ItemFlag.values());
        stack.setItemMeta(meta);
        return stack;
    }

    private ItemStack kitIcon(Player player, Kit kit) {
        Messages messages = plugin.messages();
        KitManager kits = plugin.kits();
        boolean unlocked = kits.canUse(player, kit);
        long remaining = unlocked ? kits.remainingFor(player, kit) : 0L;

        Material material = unlocked
                ? kit.icon()
                : material(plugin.getConfig().getString("gui.locked-material"), Material.RED_STAINED_GLASS_PANE);
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();

        if (unlocked) {
            meta.displayName(kit.itemName());
        } else {
            meta.displayName(messages.item("gui-locked-name",
                    Placeholder.unparsed("kit", Text.plain(kit.displayComponent()))));
        }

        List<Component> lore = new ArrayList<>();
        for (String line : kit.description()) {
            lore.add(Text.item(line));
        }
        lore.add(Component.empty());
        lore.add(messages.item("gui-lore-access", Placeholder.component("access", kit.accessComponent())));
        if (kit.cooldownSeconds() > 0) {
            lore.add(messages.item("gui-lore-cooldown",
                    Placeholder.unparsed("time", Text.duration(kit.cooldownSeconds()))));
        } else {
            lore.add(messages.item("gui-lore-cooldown-none"));
        }
        lore.add(Component.empty());
        if (!unlocked) {
            lore.add(messages.item("gui-status-locked"));
        } else if (remaining > 0) {
            lore.add(messages.item("gui-status-cooldown", Placeholder.unparsed("time", Text.duration(remaining))));
        } else {
            lore.add(messages.item("gui-status-ready"));
        }
        lore.add(messages.item("gui-hint-preview"));
        meta.lore(lore);
        meta.addItemFlags(ItemFlag.values());
        if (unlocked && remaining <= 0) {
            meta.setEnchantmentGlintOverride(true);
        }
        stack.setItemMeta(meta);
        return stack;
    }

    private static Material material(String name, Material fallback) {
        if (name == null) {
            return fallback;
        }
        Material material = Material.matchMaterial(name);
        return material != null && material.isItem() ? material : fallback;
    }
}
