package com.chirag.chiragranks;

import com.chirag.chiragranks.commands.KitCommand;
import com.chirag.chiragranks.gui.KitGUI;
import com.chirag.chiragranks.kits.KitManager;
import com.chirag.chiragranks.listeners.GUIListener;
import com.chirag.chiragranks.listeners.JoinListener;
import com.chirag.chiragranks.storage.DataStorage;
import com.chirag.chiragranks.utils.Messages;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

/** ChiragRanks (kits edition) - permission/LuckPerms-group based kits with a GUI. */
public final class ChiragRanks extends JavaPlugin {

    private Messages messages;
    private DataStorage storage;
    private KitManager kitManager;
    private KitGUI kitGUI;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveDefaultResource("kits.yml");
        saveDefaultResource("messages.yml");

        messages = new Messages(this);
        messages.load();

        storage = new DataStorage(this);
        storage.load();

        kitManager = new KitManager(this, storage);
        kitManager.load();
        kitGUI = new KitGUI(this);

        Bukkit.getPluginManager().registerEvents(new JoinListener(this), this);
        Bukkit.getPluginManager().registerEvents(new GUIListener(this), this);

        PluginCommand command = getCommand("kit");
        if (command == null) {
            getLogger().severe("Command 'kit' is missing from plugin.yml!");
        } else {
            KitCommand handler = new KitCommand(this);
            command.setExecutor(handler);
            command.setTabCompleter(handler);
        }
        getLogger().info("ChiragRanks (kits) enabled.");
    }

    @Override
    public void onDisable() {
        if (storage != null) {
            storage.saveNow();
        }
    }

    /** Reloads config.yml, messages.yml and kits.yml. Cooldown data is untouched. */
    public void reloadAll() {
        reloadConfig();
        messages.load();
        kitManager.load();
    }

    private void saveDefaultResource(String name) {
        if (!new File(getDataFolder(), name).exists()) {
            saveResource(name, false);
        }
    }

    public Messages messages() {
        return messages;
    }

    public DataStorage storage() {
        return storage;
    }

    public KitManager kits() {
        return kitManager;
    }

    public KitGUI gui() {
        return kitGUI;
    }
}
