package com.chirag.chiragranks.storage;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Persistent data for a single player: last known name and kit cooldowns. */
public final class PlayerData {

    private final UUID uuid;
    private volatile String name;
    /** kit id -> epoch millis when the cooldown expires. */
    private final Map<String, Long> cooldowns = new ConcurrentHashMap<>();

    public PlayerData(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, Long> getCooldowns() {
        return cooldowns;
    }
}
