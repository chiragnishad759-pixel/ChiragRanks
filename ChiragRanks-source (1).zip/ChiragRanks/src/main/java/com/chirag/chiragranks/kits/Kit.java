package com.chirag.chiragranks.kits;

import com.chirag.chiragranks.utils.Text;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.List;

/** An immutable kit definition loaded from kits.yml. */
public record Kit(String id, String displayName, String accessLabel, long cooldownSeconds, String permission,
                  Material icon, List<String> description, int slot, List<ItemStack> items,
                  List<PotionEffect> effects, String sound, String particle, int particleCount,
                  String broadcast) {

    public Component displayComponent() {
        return Text.parse(displayName);
    }

    /** Display name for item names (italics disabled). */
    public Component itemName() {
        return Text.item(displayName);
    }

    public Component accessComponent() {
        return Text.parse(accessLabel);
    }
}
