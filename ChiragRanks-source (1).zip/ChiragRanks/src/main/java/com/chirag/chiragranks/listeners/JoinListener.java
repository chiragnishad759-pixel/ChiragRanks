package com.chirag.chiragranks.listeners;

import com.chirag.chiragranks.ChiragRanks;
import com.chirag.chiragranks.storage.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.util.UUID;

/** Remembers player names so /kit reset works for offline players. */
public final class JoinListener implements Listener {

    private final ChiragRanks plugin;

    public JoinListener(ChiragRanks plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        PlayerData existing = plugin.storage().get(id);
        boolean dirty = existing == null || !player.getName().equals(existing.getName());
        PlayerData data = plugin.storage().getOrCreate(id, player.getName());
        data.setName(player.getName());
        if (dirty) {
            plugin.storage().saveAsync();
        }
    }
}
