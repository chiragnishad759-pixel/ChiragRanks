package com.chirag.chiragranks.ranks;

import com.chirag.chiragranks.ChiragRanks;
import com.chirag.chiragranks.storage.DataStorage;
import com.chirag.chiragranks.storage.PlayerData;
import com.chirag.chiragranks.utils.Text;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Loads ranks, resolves player ranks, applies permissions, tablist names and tablist sorting. */
public final class RankManager {

    private static final String TEAM_PREFIX = "cr_";

    private final ChiragRanks plugin;
    private final DataStorage storage;
    private volatile Map<String, Rank> ranks = Collections.emptyMap();
    private volatile List<Rank> sorted = Collections.emptyList();
    private volatile Rank defaultRank;
    private final Map<UUID, PermissionAttachment> attachments = new ConcurrentHashMap<>();

    public RankManager(ChiragRanks plugin, DataStorage storage) {
        this.plugin = plugin;
        this.storage = storage;
    }

    public boolean isLoaded() {
        return defaultRank != null && !ranks.isEmpty();
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "ranks.yml");
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection("ranks");
        Map<String, Rank> loaded = new LinkedHashMap<>();
        if (section != null) {
            for (String key : section.getKeys(false)) {
                ConfigurationSection s = section.getConfigurationSection(key);
                if (s == null) {
                    continue;
                }
                String id = key.toUpperCase(Locale.ROOT);
                Material icon = Material.matchMaterial(s.getString("gui-icon", "PAPER"));
                if (icon == null || !icon.isItem()) {
                    icon = Material.PAPER;
                }
                loaded.put(id, new Rank(
                        id,
                        s.getString("display-name", id),
                        s.getString("prefix", "[" + id + "]"),
                        s.getString("name-format", "<name>"),
                        Text.color(s.getString("chat-color"), NamedTextColor.WHITE),
                        List.copyOf(s.getStringList("permissions")),
                        s.getInt("priority", loaded.size() + 1),
                        icon));
            }
        }
        if (loaded.isEmpty()) {
            plugin.getLogger().severe("ranks.yml contains no ranks!");
            return;
        }
        List<Rank> list = new ArrayList<>(loaded.values());
        list.sort(Comparator.comparingInt(Rank::priority));
        String defId = plugin.getConfig().getString("default-rank", "MEMBER").toUpperCase(Locale.ROOT);
        Rank def = loaded.get(defId);
        if (def == null) {
            def = list.get(0);
            plugin.getLogger().warning("default-rank '" + defId + "' not found; using " + def.id());
        }
        this.ranks = Collections.unmodifiableMap(loaded);
        this.sorted = Collections.unmodifiableList(list);
        this.defaultRank = def;
        resetTeams();
        plugin.getLogger().info("Loaded " + loaded.size() + " rank(s).");
    }

    public Rank getRank(String id) {
        return id == null ? null : ranks.get(id.toUpperCase(Locale.ROOT));
    }

    /** All ranks sorted by priority, lowest first. */
    public Collection<Rank> getRanks() {
        return sorted;
    }

    public Rank getDefaultRank() {
        return defaultRank;
    }

    public Rank getPlayerRank(UUID uuid) {
        PlayerData data = storage.get(uuid);
        if (data != null && data.getRank() != null) {
            Rank rank = ranks.get(data.getRank());
            if (rank != null) {
                return rank;
            }
        }
        return defaultRank;
    }

    public boolean hasAssignedRank(UUID uuid) {
        PlayerData data = storage.get(uuid);
        return data != null && data.getRank() != null;
    }

    public void setRank(UUID uuid, String name, Rank rank, String assignedBy) {
        PlayerData data = storage.getOrCreate(uuid, name);
        data.setName(name);
        data.setRank(rank.id());
        data.setAssignedBy(assignedBy);
        data.setAssignedAt(System.currentTimeMillis());
        storage.saveAsync();
        Player online = Bukkit.getPlayer(uuid);
        if (online != null) {
            apply(online);
        }
    }

    /** Clears an assigned rank. Returns false if the player had none. */
    public boolean removeRank(UUID uuid) {
        PlayerData data = storage.get(uuid);
        if (data == null || data.getRank() == null) {
            return false;
        }
        data.setRank(null);
        data.setAssignedBy(null);
        data.setAssignedAt(0L);
        storage.saveAsync();
        Player online = Bukkit.getPlayer(uuid);
        if (online != null) {
            apply(online);
        }
        return true;
    }

    /** Applies permissions, display name, tablist name and tablist order for a player. */
    public void apply(Player player) {
        Rank rank = getPlayerRank(player.getUniqueId());
        applyPermissions(player, rank);

        FileConfiguration config = plugin.getConfig();
        player.displayName(rank.formatName(player.getName()));

        if (config.getBoolean("tablist.enabled", true)) {
            String format = config.getString("tablist.format", "<prefix> <name>");
            player.playerListName(Text.parse(format,
                    Placeholder.component("prefix", rank.prefixComponent()),
                    Placeholder.component("name", rank.formatName(player.getName()))));
            if (config.getBoolean("tablist.sort-by-rank", true)) {
                updateTeam(player, rank);
            } else {
                removeFromTeams(player, null);
            }
        } else {
            player.playerListName(null);
            removeFromTeams(player, null);
        }
    }

    public void refreshAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            apply(player);
        }
    }

    public void handleQuit(Player player) {
        PermissionAttachment attachment = attachments.remove(player.getUniqueId());
        if (attachment != null) {
            try {
                player.removeAttachment(attachment);
            } catch (IllegalArgumentException ignored) {
                // attachment already removed
            }
        }
        removeFromTeams(player, null);
    }

    public void shutdown() {
        for (Map.Entry<UUID, PermissionAttachment> entry : attachments.entrySet()) {
            Player player = Bukkit.getPlayer(entry.getKey());
            if (player != null) {
                try {
                    player.removeAttachment(entry.getValue());
                } catch (IllegalArgumentException ignored) {
                    // already removed
                }
                player.playerListName(null);
                player.displayName(null);
            }
        }
        attachments.clear();
        resetTeams();
    }

    private void applyPermissions(Player player, Rank rank) {
        PermissionAttachment old = attachments.remove(player.getUniqueId());
        if (old != null) {
            try {
                player.removeAttachment(old);
            } catch (IllegalArgumentException ignored) {
                // already removed
            }
        }
        PermissionAttachment attachment = player.addAttachment(plugin);
        for (Rank r : sorted) {
            if (r.priority() > rank.priority()) {
                break;
            }
            for (String permission : r.permissions()) {
                if (permission.isBlank()) {
                    continue;
                }
                boolean value = !permission.startsWith("-");
                String node = value ? permission : permission.substring(1);
                attachment.setPermission(node, value);
            }
        }
        attachments.put(player.getUniqueId(), attachment);
    }

    private String teamName(Rank rank) {
        int order = Math.max(0, Math.min(99, 99 - rank.priority()));
        String name = String.format("%s%02d_%s", TEAM_PREFIX, order, rank.id());
        return name.length() > 16 ? name.substring(0, 16) : name;
    }

    private void updateTeam(Player player, Rank rank) {
        if (Bukkit.getScoreboardManager() == null) {
            return;
        }
        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
        String wanted = teamName(rank);
        removeFromTeams(player, wanted);
        Team team = board.getTeam(wanted);
        if (team == null) {
            team = board.registerNewTeam(wanted);
        }
        if (!team.hasEntry(player.getName())) {
            team.addEntry(player.getName());
        }
    }

    private void removeFromTeams(Player player, String except) {
        if (Bukkit.getScoreboardManager() == null) {
            return;
        }
        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Team team : new ArrayList<>(board.getTeams())) {
            if (team.getName().startsWith(TEAM_PREFIX) && !team.getName().equals(except)
                    && team.hasEntry(player.getName())) {
                team.removeEntry(player.getName());
            }
        }
    }

    private void resetTeams() {
        if (Bukkit.getScoreboardManager() == null) {
            return;
        }
        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Team team : new ArrayList<>(board.getTeams())) {
            if (team.getName().startsWith(TEAM_PREFIX)) {
                team.unregister();
            }
        }
    }
}
