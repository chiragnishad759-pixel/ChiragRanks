package com.chirag.chiragranks.utils;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;

import java.util.Locale;

/** MiniMessage helpers. */
public final class Text {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private Text() {
    }

    public static Component parse(String input, TagResolver... resolvers) {
        return MM.deserialize(input == null ? "" : input, resolvers);
    }

    /** Parses text for item names/lore: italics are disabled unless the text asks for them. */
    public static Component item(String input, TagResolver... resolvers) {
        return parse(input, resolvers).decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    public static String plain(Component component) {
        return PlainTextComponentSerializer.plainText().serialize(component);
    }

    public static TextColor color(String value, TextColor fallback) {
        if (value == null || value.isBlank()) {
            return fallback;
        }
        String v = value.trim();
        if (v.startsWith("#")) {
            TextColor hex = TextColor.fromHexString(v);
            return hex != null ? hex : fallback;
        }
        NamedTextColor named = NamedTextColor.NAMES.value(v.toLowerCase(Locale.ROOT));
        return named != null ? named : fallback;
    }

    public static String duration(long totalSeconds) {
        if (totalSeconds <= 0) {
            return "0s";
        }
        long d = totalSeconds / 86400;
        long h = (totalSeconds % 86400) / 3600;
        long m = (totalSeconds % 3600) / 60;
        long s = totalSeconds % 60;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append("d ");
        if (h > 0) sb.append(h).append("h ");
        if (m > 0) sb.append(m).append("m ");
        if (s > 0 && d == 0) sb.append(s).append("s");
        return sb.toString().trim();
    }
}
