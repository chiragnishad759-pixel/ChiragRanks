package com.chirag.chiragranks;

import com.chirag.chiragranks.commands.KitCommand;
import com.chirag.chiragranks.commands.RankCommand;
import com.chirag.chiragranks.commands.RanksCommand;
import com.chirag.chiragranks.gui.KitGUI;
import com.chirag.chiragranks.kits.KitManager;
import com.chirag.chiragranks.listeners.ChatListener;
import com.chirag.chiragranks.listeners.GUIListener;
import com.chirag.chiragranks.listeners.JoinQuitListener;
import com.chirag.chiragranks.ranks.RankManager;
import com.chirag.chiragranks.storage.DataStorage;
import com.chirag.chiragranks.utils.Messages;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

/** ChiragRanks - ranks, kits, chat/tablist formatting and a kit GUI. */
public final class ChiragRanks extends JavaPlugin {

    private Messages messages;
    private DataStorage storage;
    private RankManager rankManager;
    private KitManager kitManager;
    private KitGUI kitGUI;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveDefaultResource("ranks.yml");
        saveDefaultResource("kits.yml");
        saveDefaultResource("messages.yml");

        messages = new Messages(this);
        messages.load();

        storage = new DataStorage(this);
        storage.load();

        rankManager = new RankManager(this, storage);
        rankManager.load();
        if (!rankManager.isLoaded()) {
            getLogger().severe("No ranks could be loaded from ranks.yml - disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        kitManager = new KitManager(this, storage);
        kitManager.load();
        kitGUI = new KitGUI(this);

        Bukkit.getPluginManager().registerEvents(new JoinQuitListener(this), this);
        Bukkit.getPluginManager().registerEvents(new ChatListener(this), this);
        Bukkit.getPluginManager().registerEvents(new GUIListener(this), this);

        registerCommand("rank", new RankCommand(this));
        registerCommand("ranks", new RanksCommand(this));
        registerCommand("kit", new KitCommand(this));

        // Support /reload: apply ranks to players who are already online.
        for (Player player : Bukkit.getOnlinePlayers()) {
            rankManager.apply(player);
        }
        getLogger().info("ChiragRanks enabled.");
    }

    @Override
    public void onDisable() {
        if (rankManager != null) {
            rankManager.shutdown();
        }
        if (storage != null) {
            storage.saveNow();
        }
    }

    /** Reloads config.yml, messages.yml, ranks.yml and kits.yml. Player data is untouched. */
    public void reloadAll() {
        reloadConfig();
        messages.load();
        rankManager.load();
        kitManager.load();
        rankManager.refreshAll();
    }

    private void registerCommand(String name, TabExecutor handler) {
        PluginCommand command = getCommand(name);
        if (command == null) {
            getLogger().severe("Command '" + name + "' is missing from plugin.yml!");
            return;
        }
        command.setExecutor(handler);
        command.setTabCompleter(handler);
    }

    private void saveDefaultResource(String name) {
        if (!new File(getDataFolder(), name).exists()) {
            saveResource(name, false);
        }
    }

    public Messages messages() {
        return messages;
    }

    public DataStorage storage() {
        return storage;
    }

    public RankManager ranks() {
        return rankManager;
    }

    public KitManager kits() {
        return kitManager;
    }

    public KitGUI gui() {
        return kitGUI;
    }
}
