package com.chirag.chiragranks.ranks;

import com.chirag.chiragranks.utils.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Material;

import java.util.List;

/** An immutable rank definition loaded from ranks.yml. */
public record Rank(String id, String displayName, String prefix, String nameFormat, TextColor chatColor,
                   List<String> permissions, int priority, Material guiIcon) {

    public Component displayComponent() {
        return Text.parse(displayName);
    }

    public Component prefixComponent() {
        return Text.parse(prefix);
    }

    /** The player's name rendered with this rank's name format (gradient etc.). */
    public Component formatName(String playerName) {
        return Text.parse(nameFormat, Placeholder.unparsed("name", playerName));
    }
}
