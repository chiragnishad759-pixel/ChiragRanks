package com.chirag.chiragranks.kits;

import com.chirag.chiragranks.ChiragRanks;
import com.chirag.chiragranks.storage.DataStorage;
import com.chirag.chiragranks.storage.PlayerData;
import com.chirag.chiragranks.utils.ItemParser;
import com.chirag.chiragranks.utils.Messages;
import com.chirag.chiragranks.utils.Text;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Loads kits, validates claims, tracks cooldowns and hands out items safely. */
public final class KitManager {

    public static final String BYPASS_PERMISSION = "chiragranks.bypass.cooldown";

    public record ClaimResult(Status status, long remainingSeconds, int slotsNeeded) {
        public enum Status { SUCCESS, LOCKED, COOLDOWN, NO_SPACE, EMPTY }
    }

    private final ChiragRanks plugin;
    private final DataStorage storage;
    private volatile Map<String, Kit> kits = Collections.emptyMap();

    public KitManager(ChiragRanks plugin, DataStorage storage) {
        this.plugin = plugin;
        this.storage = storage;
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "kits.yml");
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection("kits");
        Map<String, Kit> loaded = new LinkedHashMap<>();
        boolean unsafe = plugin.getConfig().getBoolean("kits.allow-unsafe-enchant-levels", false);
        if (section != null) {
            for (String key : section.getKeys(false)) {
                ConfigurationSection s = section.getConfigurationSection(key);
                if (s == null) {
                    continue;
                }
                String id = key.toLowerCase(Locale.ROOT);
                List<ItemStack> items = new ArrayList<>();
                for (Map<?, ?> raw : s.getMapList("items")) {
                    ItemStack item = ItemParser.parse(raw, unsafe, plugin.getLogger(), "kit:" + id);
                    if (item != null) {
                        items.add(item);
                    }
                }
                List<PotionEffect> effects = new ArrayList<>();
                for (Map<?, ?> raw : s.getMapList("on-claim.effects")) {
                    NamespacedKey effectKey = ItemParser.key(raw.get("effect"));
                    PotionEffectType type = effectKey == null ? null : Registry.EFFECT.get(effectKey);
                    if (type == null) {
                        plugin.getLogger().warning("[kit:" + id + "] Unknown potion effect '" + raw.get("effect") + "' - skipped.");
                        continue;
                    }
                    int seconds = Math.max(1, ItemParser.number(raw.get("duration"), 10));
                    int amplifier = Math.max(0, ItemParser.number(raw.get("amplifier"), 0));
                    effects.add(new PotionEffect(type, seconds * 20, amplifier));
                }
                Material icon = Material.matchMaterial(s.getString("icon", "CHEST"));
                if (icon == null || !icon.isItem()) {
                    icon = Material.CHEST;
                }
                loaded.put(id, new Kit(
                        id,
                        s.getString("display-name", id),
                        s.getString("access-label", "<gray>Permission required"),
                        Math.max(0L, s.getLong("cooldown", 0L)),
                        s.getString("permission", "chiragranks.kit." + id),
                        icon,
                        List.copyOf(s.getStringList("description")),
                        s.getInt("slot", -1),
                        List.copyOf(items),
                        List.copyOf(effects),
                        s.getString("on-claim.sound"),
                        s.getString("on-claim.particle"),
                        s.getInt("on-claim.particle-count", 30),
                        s.getString("on-claim.broadcast")));
            }
        }
        this.kits = Collections.unmodifiableMap(loaded);
        plugin.getLogger().info("Loaded " + loaded.size() + " kit(s).");
    }

    public Kit getKit(String id) {
        return id == null ? null : kits.get(id.toLowerCase(Locale.ROOT));
    }

    public Collection<Kit> getKits() {
        return kits.values();
    }

    /** True for players in one of the configured staff groups (LuckPerms "group.<name>") or with chiragranks.admin. */
    public boolean isStaff(Player player) {
        if (player.hasPermission("chiragranks.admin")) {
            return true;
        }
        for (String group : plugin.getConfig().getStringList("kits.staff-groups")) {
            if (!group.isBlank() && player.hasPermission("group." + group.trim().toLowerCase(Locale.ROOT))) {
                return true;
            }
        }
        return false;
    }

    /** A player may use a kit if they hold its permission or are staff. */
    public boolean canUse(Player player, Kit kit) {
        return player.hasPermission(kit.permission()) || isStaff(player);
    }

    /** True if the player may ignore cooldowns. */
    public boolean bypassesCooldown(Player player) {
        if (player.hasPermission(BYPASS_PERMISSION)) {
            return true;
        }
        return plugin.getConfig().getBoolean("kits.staff-bypass-cooldown", true) && isStaff(player);
    }

    public long remainingSeconds(UUID uuid, Kit kit) {
        return remainingSeconds(uuid, kit.id());
    }

    public long remainingSeconds(UUID uuid, String cooldownKey) {
        PlayerData data = storage.get(uuid);
        if (data == null) {
            return 0L;
        }
        Long expiry = data.getCooldowns().get(cooldownKey);
        if (expiry == null) {
            return 0L;
        }
        long millis = expiry - System.currentTimeMillis();
        return millis <= 0 ? 0L : (millis + 999L) / 1000L;
    }

    /** Remaining cooldown for a player, taking the bypass permission into account. */
    public long remainingFor(Player player, Kit kit) {
        if (bypassesCooldown(player)) {
            return 0L;
        }
        return remainingSeconds(player.getUniqueId(), kit);
    }

    public void resetCooldown(UUID uuid, String kitId) {
        PlayerData data = storage.get(uuid);
        if (data == null) {
            return;
        }
        if (kitId == null) {
            data.getCooldowns().clear();
        } else {
            data.getCooldowns().remove(kitId.toLowerCase(Locale.ROOT));
        }
        storage.saveAsync();
    }

    public ClaimResult claim(Player player, Kit kit) {
        boolean bypass = bypassesCooldown(player);
        return doClaim(player, kit, false, kit.id(), kit.cooldownSeconds(), bypass);
    }

    /**
     * Core claim logic. cooldownKey may be null for "no cooldown tracking".
     * Items are only handed out if everything fits, so nothing is ever lost.
     */
    private ClaimResult doClaim(Player player, Kit kit, boolean skipAccess, String cooldownKey,
                                long cooldownSeconds, boolean ignoreCooldown) {
        if (!skipAccess && !canUse(player, kit)) {
            return new ClaimResult(ClaimResult.Status.LOCKED, 0, 0);
        }
        if (kit.items().isEmpty()) {
            return new ClaimResult(ClaimResult.Status.EMPTY, 0, 0);
        }
        if (cooldownKey != null && !ignoreCooldown) {
            long remaining = remainingSeconds(player.getUniqueId(), cooldownKey);
            if (remaining > 0) {
                return new ClaimResult(ClaimResult.Status.COOLDOWN, remaining, 0);
            }
        }

        // Plan: which pieces get auto-equipped and which go to the inventory.
        PlayerInventory inventory = player.getInventory();
        boolean autoEquip = plugin.getConfig().getBoolean("kits.auto-equip-armor", true);
        Map<EquipmentSlot, ItemStack> equip = new EnumMap<>(EquipmentSlot.class);
        List<ItemStack> toInventory = new ArrayList<>();
        for (ItemStack template : kit.items()) {
            ItemStack item = template.clone();
            EquipmentSlot slot = autoEquip ? armorSlot(item.getType()) : null;
            if (slot != null && !equip.containsKey(slot) && isEmpty(getArmor(inventory, slot))) {
                equip.put(slot, item);
            } else {
                toInventory.add(item);
            }
        }

        int missing = missingSlots(inventory, toInventory);
        if (missing > 0) {
            return new ClaimResult(ClaimResult.Status.NO_SPACE, 0, missing);
        }

        // Everything fits: hand it out.
        for (Map.Entry<EquipmentSlot, ItemStack> entry : equip.entrySet()) {
            setArmor(inventory, entry.getKey(), entry.getValue());
        }
        Map<Integer, ItemStack> leftover = inventory.addItem(toInventory.toArray(new ItemStack[0]));
        for (ItemStack extra : leftover.values()) {
            // Should never happen because of the pre-check; never lose an item anyway.
            player.getWorld().dropItemNaturally(player.getLocation(), extra);
        }

        if (cooldownKey != null && !ignoreCooldown && cooldownSeconds > 0) {
            PlayerData data = storage.getOrCreate(player.getUniqueId(), player.getName());
            data.getCooldowns().put(cooldownKey, System.currentTimeMillis() + cooldownSeconds * 1000L);
            storage.saveAsync();
        }
        playEffects(player, kit);
        return new ClaimResult(ClaimResult.Status.SUCCESS, 0, 0);
    }

    /** Claims a kit and sends the matching message. Returns true on success. */
    public boolean claimAndNotify(Player player, Kit kit) {
        ClaimResult result = claim(player, kit);
        Messages messages = plugin.messages();
        switch (result.status()) {
            case SUCCESS:
                messages.send(player, "kit-claimed", Placeholder.component("kit", kit.displayComponent()));
                return true;
            case LOCKED:
                messages.send(player, "kit-no-access",
                        Placeholder.component("kit", kit.displayComponent()),
                        Placeholder.component("access", kit.accessComponent()));
                return false;
            case COOLDOWN:
                messages.send(player, "kit-cooldown",
                        Placeholder.component("kit", kit.displayComponent()),
                        Placeholder.unparsed("time", Text.duration(result.remainingSeconds())));
                return false;
            case NO_SPACE:
                messages.send(player, "kit-no-space",
                        Placeholder.unparsed("slots", String.valueOf(result.slotsNeeded())));
                return false;
            default:
                messages.send(player, "kit-empty");
                return false;
        }
    }

    /** Name of the free-offer subcommand (default "freevipkit"). */
    public String freeCommandName() {
        return plugin.getConfig().getString("free-kit.command", "freevipkit").toLowerCase(Locale.ROOT);
    }

    public boolean isFreeOfferEnabled() {
        return plugin.getConfig().getBoolean("free-kit.enabled", true);
    }

    /** /kit freevipkit - gives the configured kit for free to players who do not already have access to it. */
    public void claimFreeOffer(Player player) {
        Messages messages = plugin.messages();
        var config = plugin.getConfig();
        if (!isFreeOfferEnabled()) {
            messages.send(player, "free-kit-disabled");
            return;
        }
        String endDate = config.getString("free-kit.end-date", "");
        if (endDate != null && !endDate.isBlank()) {
            try {
                ZoneId zone = ZoneId.of(config.getString("free-kit.timezone", "Asia/Kolkata"));
                if (LocalDate.now(zone).isAfter(LocalDate.parse(endDate.trim()))) {
                    messages.send(player, "free-kit-ended");
                    return;
                }
            } catch (DateTimeException ex) {
                plugin.getLogger().warning("Invalid free-kit.end-date or free-kit.timezone: " + ex.getMessage());
            }
        }

        String kitId = config.getString("free-kit.kit", "vip");
        Kit kit = getKit(kitId);
        if (kit == null) {
            messages.send(player, "kit-not-found",
                    Placeholder.unparsed("kit", String.valueOf(kitId)),
                    Placeholder.unparsed("kits", String.join(", ", kits.keySet())));
            return;
        }
        if (canUse(player, kit)) {
            messages.send(player, "free-kit-already-access", Placeholder.component("kit", kit.displayComponent()));
            return;
        }

        boolean once = config.getBoolean("free-kit.once-per-player", true);
        String key = "free-" + kit.id();
        PlayerData data = storage.getOrCreate(player.getUniqueId(), player.getName());
        if (once && data.getFreeClaims().contains(key)) {
            messages.send(player, "free-kit-used", Placeholder.component("kit", kit.displayComponent()));
            return;
        }
        long cooldown = once ? 0L : Math.max(0L, config.getLong("free-kit.cooldown-seconds", 86400L));
        ClaimResult result = doClaim(player, kit, true, once ? null : key, cooldown, false);
        switch (result.status()) {
            case SUCCESS:
                if (once) {
                    data.getFreeClaims().add(key);
                    storage.saveAsync();
                }
                messages.send(player, "free-kit-claimed", Placeholder.component("kit", kit.displayComponent()));
                break;
            case COOLDOWN:
                messages.send(player, "kit-cooldown",
                        Placeholder.component("kit", kit.displayComponent()),
                        Placeholder.unparsed("time", Text.duration(result.remainingSeconds())));
                break;
            case NO_SPACE:
                messages.send(player, "kit-no-space",
                        Placeholder.unparsed("slots", String.valueOf(result.slotsNeeded())));
                break;
            default:
                messages.send(player, "kit-empty");
                break;
        }
    }

    /** Lets a player claim the free offer again (staff reset). */
    public void resetFreeOffer(UUID uuid) {
        PlayerData data = storage.get(uuid);
        if (data == null) {
            return;
        }
        data.getFreeClaims().clear();
        data.getCooldowns().keySet().removeIf(key -> key.startsWith("free-"));
        storage.saveAsync();
    }

    private int missingSlots(PlayerInventory inventory, List<ItemStack> items) {
        Inventory simulation = Bukkit.createInventory(null, 36);
        ItemStack[] current = inventory.getStorageContents();
        ItemStack[] copy = new ItemStack[36];
        for (int i = 0; i < current.length && i < copy.length; i++) {
            copy[i] = current[i] == null ? null : current[i].clone();
        }
        simulation.setContents(copy);
        ItemStack[] toAdd = new ItemStack[items.size()];
        for (int i = 0; i < toAdd.length; i++) {
            toAdd[i] = items.get(i).clone();
        }
        Map<Integer, ItemStack> left = simulation.addItem(toAdd);
        int slots = 0;
        for (ItemStack stack : left.values()) {
            slots += (int) Math.ceil(stack.getAmount() / (double) Math.max(1, stack.getMaxStackSize()));
        }
        return slots;
    }

    private static boolean isEmpty(ItemStack item) {
        return item == null || item.getType().isAir();
    }

    private static EquipmentSlot armorSlot(Material material) {
        String name = material.name();
        if (name.endsWith("_HELMET")) return EquipmentSlot.HEAD;
        if (name.endsWith("_CHESTPLATE")) return EquipmentSlot.CHEST;
        if (name.endsWith("_LEGGINGS")) return EquipmentSlot.LEGS;
        if (name.endsWith("_BOOTS")) return EquipmentSlot.FEET;
        return null;
    }

    private static ItemStack getArmor(PlayerInventory inventory, EquipmentSlot slot) {
        switch (slot) {
            case HEAD: return inventory.getHelmet();
            case CHEST: return inventory.getChestplate();
            case LEGS: return inventory.getLeggings();
            default: return inventory.getBoots();
        }
    }

    private static void setArmor(PlayerInventory inventory, EquipmentSlot slot, ItemStack item) {
        switch (slot) {
            case HEAD: inventory.setHelmet(item); break;
            case CHEST: inventory.setChestplate(item); break;
            case LEGS: inventory.setLeggings(item); break;
            default: inventory.setBoots(item); break;
        }
    }

    private void playEffects(Player player, Kit kit) {
        for (PotionEffect effect : kit.effects()) {
            player.addPotionEffect(effect);
        }
        if (kit.sound() != null && !kit.sound().isBlank()) {
            player.playSound(player.getLocation(), kit.sound(), 1.0f, 1.0f);
        }
        if (kit.particle() != null && !kit.particle().isBlank()) {
            try {
                Particle particle = Particle.valueOf(kit.particle().toUpperCase(Locale.ROOT));
                player.getWorld().spawnParticle(particle, player.getLocation().add(0, 1, 0),
                        Math.max(1, kit.particleCount()), 0.5, 0.8, 0.5, 0.05);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("[kit:" + kit.id() + "] Unknown particle '" + kit.particle() + "'.");
            }
        }
        if (kit.broadcast() != null && !kit.broadcast().isBlank()) {
            Bukkit.broadcast(Text.parse(kit.broadcast(), Placeholder.unparsed("player", player.getName())));
        }
    }
}
