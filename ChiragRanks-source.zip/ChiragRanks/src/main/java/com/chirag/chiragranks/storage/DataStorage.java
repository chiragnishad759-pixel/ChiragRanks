package com.chirag.chiragranks.storage;

import com.chirag.chiragranks.ChiragRanks;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;

/** YAML persistence (data.yml). Snapshots are built on the main thread and written asynchronously. */
public final class DataStorage {

    private final ChiragRanks plugin;
    private final File file;
    private final Map<UUID, PlayerData> players = new ConcurrentHashMap<>();
    private final Object ioLock = new Object();
    private final AtomicLong versionCounter = new AtomicLong();
    private long lastWritten = 0;

    public DataStorage(ChiragRanks plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    public void load() {
        players.clear();
        if (!plugin.getDataFolder().exists() && !plugin.getDataFolder().mkdirs()) {
            plugin.getLogger().warning("Could not create the plugin data folder.");
        }
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection("players");
        if (section == null) {
            return;
        }
        long now = System.currentTimeMillis();
        for (String key : section.getKeys(false)) {
            UUID id;
            try {
                id = UUID.fromString(key);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Ignoring invalid UUID in data.yml: " + key);
                continue;
            }
            ConfigurationSection p = section.getConfigurationSection(key);
            if (p == null) {
                continue;
            }
            PlayerData data = new PlayerData(id, p.getString("name", "unknown"));
            data.setRank(p.getString("rank"));
            data.setAssignedBy(p.getString("assigned-by"));
            data.setAssignedAt(p.getLong("assigned-at"));
            ConfigurationSection cooldowns = p.getConfigurationSection("cooldowns");
            if (cooldowns != null) {
                for (String kit : cooldowns.getKeys(false)) {
                    long expiry = cooldowns.getLong(kit);
                    if (expiry > now) {
                        data.getCooldowns().put(kit.toLowerCase(Locale.ROOT), expiry);
                    }
                }
            }
            players.put(id, data);
        }
        plugin.getLogger().info("Loaded data for " + players.size() + " player(s).");
    }

    public PlayerData get(UUID uuid) {
        return players.get(uuid);
    }

    public PlayerData getOrCreate(UUID uuid, String name) {
        return players.computeIfAbsent(uuid, id -> new PlayerData(id, name));
    }

    public PlayerData findByName(String name) {
        for (PlayerData data : players.values()) {
            if (data.getName() != null && data.getName().equalsIgnoreCase(name)) {
                return data;
            }
        }
        return null;
    }

    public void saveAsync() {
        long version = versionCounter.incrementAndGet();
        String yaml = buildYaml();
        if (!plugin.isEnabled()) {
            write(version, yaml);
            return;
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> write(version, yaml));
    }

    public void saveNow() {
        long version = versionCounter.incrementAndGet();
        write(version, buildYaml());
    }

    private String buildYaml() {
        YamlConfiguration yaml = new YamlConfiguration();
        long now = System.currentTimeMillis();
        for (PlayerData data : players.values()) {
            String base = "players." + data.getUuid();
            yaml.set(base + ".name", data.getName());
            if (data.getRank() != null) {
                yaml.set(base + ".rank", data.getRank());
                yaml.set(base + ".assigned-by", data.getAssignedBy());
                yaml.set(base + ".assigned-at", data.getAssignedAt());
            }
            for (Map.Entry<String, Long> entry : data.getCooldowns().entrySet()) {
                if (entry.getValue() > now) {
                    yaml.set(base + ".cooldowns." + entry.getKey(), entry.getValue());
                }
            }
        }
        return yaml.saveToString();
    }

    private void write(long version, String yaml) {
        synchronized (ioLock) {
            if (version < lastWritten) {
                return;
            }
            lastWritten = version;
            try {
                Path target = file.toPath();
                Path tmp = target.resolveSibling("data.yml.tmp");
                Files.writeString(tmp, yaml, StandardCharsets.UTF_8);
                try {
                    Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (AtomicMoveNotSupportedException ex) {
                    Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
                }
            } catch (IOException ex) {
                plugin.getLogger().log(Level.SEVERE, "Failed to save data.yml", ex);
            }
        }
    }
}
