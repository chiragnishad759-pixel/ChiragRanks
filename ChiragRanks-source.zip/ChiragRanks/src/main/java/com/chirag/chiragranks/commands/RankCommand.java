package com.chirag.chiragranks.commands;

import com.chirag.chiragranks.ChiragRanks;
import com.chirag.chiragranks.kits.Kit;
import com.chirag.chiragranks.ranks.Rank;
import com.chirag.chiragranks.storage.PlayerData;
import com.chirag.chiragranks.utils.Completions;
import com.chirag.chiragranks.utils.Messages;
import com.chirag.chiragranks.utils.PlayerLookup;
import com.chirag.chiragranks.utils.PlayerLookup.Target;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.StringJoiner;
import java.util.UUID;

/** /rank set|remove|info|list|reload and the shortcut /rank <player> <rank>. */
public final class RankCommand implements TabExecutor {

    private static final DateTimeFormatter DATE_FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.systemDefault());

    private final ChiragRanks plugin;

    public RankCommand(ChiragRanks plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Messages messages = plugin.messages();
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            messages.sendLines(sender, "usage-rank");
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "set":
                if (args.length < 3) {
                    messages.sendLines(sender, "usage-rank");
                    return true;
                }
                return handleSet(sender, args[1], args[2]);
            case "remove":
                if (args.length < 2) {
                    messages.sendLines(sender, "usage-rank");
                    return true;
                }
                return handleRemove(sender, args[1]);
            case "info":
                if (args.length < 2) {
                    messages.sendLines(sender, "usage-rank");
                    return true;
                }
                return handleInfo(sender, args[1]);
            case "list":
                if (!sender.hasPermission("chiragranks.rank.list")) {
                    messages.send(sender, "no-permission");
                    return true;
                }
                sendRankList(plugin, sender);
                return true;
            case "reload":
                if (!sender.hasPermission("chiragranks.reload")) {
                    messages.send(sender, "no-permission");
                    return true;
                }
                plugin.reloadAll();
                messages.send(sender, "reloaded");
                return true;
            default:
                if (args.length == 2) {
                    return handleSet(sender, args[0], args[1]);
                }
                messages.sendLines(sender, "usage-rank");
                return true;
        }
    }

    private boolean handleSet(CommandSender sender, String playerName, String rankName) {
        Messages messages = plugin.messages();
        if (!sender.hasPermission("chiragranks.rank.set")) {
            messages.send(sender, "no-permission");
            return true;
        }
        Rank rank = plugin.ranks().getRank(rankName);
        if (rank == null) {
            messages.send(sender, "rank-not-found",
                    Placeholder.unparsed("rank", rankName),
                    Placeholder.unparsed("ranks", rankIds()));
            return true;
        }
        Target target = PlayerLookup.find(plugin, playerName);
        if (target == null) {
            messages.send(sender, "player-not-found", Placeholder.unparsed("player", playerName));
            return true;
        }
        if (!canManage(sender, target.uuid(), rank)) {
            messages.send(sender, "rank-too-high");
            return true;
        }
        plugin.ranks().setRank(target.uuid(), target.name(), rank, sender.getName());
        messages.send(sender, "rank-set",
                Placeholder.unparsed("player", target.name()),
                Placeholder.component("rank", rank.displayComponent()));
        if (target.online() != null && !target.online().equals(sender)) {
            messages.send(target.online(), "rank-set-target", Placeholder.component("rank", rank.displayComponent()));
        }
        return true;
    }

    private boolean handleRemove(CommandSender sender, String playerName) {
        Messages messages = plugin.messages();
        if (!sender.hasPermission("chiragranks.rank.remove")) {
            messages.send(sender, "no-permission");
            return true;
        }
        Target target = PlayerLookup.find(plugin, playerName);
        if (target == null) {
            messages.send(sender, "player-not-found", Placeholder.unparsed("player", playerName));
            return true;
        }
        if (!canManage(sender, target.uuid(), null)) {
            messages.send(sender, "rank-too-high");
            return true;
        }
        if (!plugin.ranks().removeRank(target.uuid())) {
            messages.send(sender, "rank-none-assigned", Placeholder.unparsed("player", target.name()));
            return true;
        }
        Rank now = plugin.ranks().getPlayerRank(target.uuid());
        messages.send(sender, "rank-removed",
                Placeholder.unparsed("player", target.name()),
                Placeholder.component("rank", now.displayComponent()));
        if (target.online() != null && !target.online().equals(sender)) {
            messages.send(target.online(), "rank-removed-target", Placeholder.component("rank", now.displayComponent()));
        }
        return true;
    }

    private boolean handleInfo(CommandSender sender, String playerName) {
        Messages messages = plugin.messages();
        if (!sender.hasPermission("chiragranks.rank.info")) {
            messages.send(sender, "no-permission");
            return true;
        }
        Target target = PlayerLookup.find(plugin, playerName);
        if (target == null) {
            messages.send(sender, "player-not-found", Placeholder.unparsed("player", playerName));
            return true;
        }
        Rank rank = plugin.ranks().getPlayerRank(target.uuid());
        PlayerData data = plugin.storage().get(target.uuid());
        boolean assigned = data != null && data.getRank() != null;
        String assignedBy = assigned && data.getAssignedBy() != null ? data.getAssignedBy() : "-";
        String assignedAt = assigned && data.getAssignedAt() > 0
                ? DATE_FORMAT.format(Instant.ofEpochMilli(data.getAssignedAt())) : "-";

        StringJoiner kitNames = new StringJoiner(", ");
        for (Kit kit : plugin.kits().getKits()) {
            Rank required = plugin.kits().requiredRank(kit);
            if (required != null && required.priority() <= rank.priority()) {
                kitNames.add(kit.id());
            }
        }
        messages.sendLines(sender, "rank-info",
                Placeholder.unparsed("player", target.name()),
                Placeholder.component("rank", rank.displayComponent()),
                Placeholder.unparsed("priority", String.valueOf(rank.priority())),
                Placeholder.unparsed("assigned_by", assignedBy),
                Placeholder.unparsed("assigned_at", assignedAt),
                Placeholder.unparsed("kits", kitNames.length() == 0 ? "-" : kitNames.toString()));
        return true;
    }

    /** Sender may only manage ranks strictly below their own unless they have chiragranks.admin. */
    private boolean canManage(CommandSender sender, UUID target, Rank newRank) {
        if (!(sender instanceof Player player) || player.hasPermission("chiragranks.admin")) {
            return true;
        }
        int own = plugin.ranks().getPlayerRank(player.getUniqueId()).priority();
        if (newRank != null && newRank.priority() >= own) {
            return false;
        }
        return plugin.ranks().getPlayerRank(target).priority() < own;
    }

    private String rankIds() {
        StringJoiner joiner = new StringJoiner(", ");
        for (Rank rank : plugin.ranks().getRanks()) {
            joiner.add(rank.id());
        }
        return joiner.toString();
    }

    /** Prints every rank, highest first. Shared with /ranks. */
    public static void sendRankList(ChiragRanks plugin, CommandSender sender) {
        Messages messages = plugin.messages();
        messages.sendLines(sender, "rank-list-header");
        List<Rank> ordered = new ArrayList<>(plugin.ranks().getRanks());
        for (int i = ordered.size() - 1; i >= 0; i--) {
            Rank rank = ordered.get(i);
            sender.sendMessage(messages.component("rank-list-entry",
                    Placeholder.component("prefix", rank.prefixComponent()),
                    Placeholder.unparsed("priority", String.valueOf(rank.priority()))));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> options = new ArrayList<>();
        if (args.length == 1) {
            if (sender.hasPermission("chiragranks.rank.set")) options.add("set");
            if (sender.hasPermission("chiragranks.rank.remove")) options.add("remove");
            if (sender.hasPermission("chiragranks.rank.info")) options.add("info");
            if (sender.hasPermission("chiragranks.rank.list")) options.add("list");
            if (sender.hasPermission("chiragranks.reload")) options.add("reload");
            if (sender.hasPermission("chiragranks.rank.set")) options.addAll(Completions.onlinePlayers());
            return Completions.filter(options, args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2) {
            switch (sub) {
                case "set":
                    return sender.hasPermission("chiragranks.rank.set")
                            ? Completions.filter(Completions.onlinePlayers(), args[1]) : List.of();
                case "remove":
                    return sender.hasPermission("chiragranks.rank.remove")
                            ? Completions.filter(Completions.onlinePlayers(), args[1]) : List.of();
                case "info":
                    return sender.hasPermission("chiragranks.rank.info")
                            ? Completions.filter(Completions.onlinePlayers(), args[1]) : List.of();
                case "list":
                case "reload":
                case "help":
                    return List.of();
                default:
                    return sender.hasPermission("chiragranks.rank.set")
                            ? Completions.filter(rankIdList(), args[1]) : List.of();
            }
        }
        if (args.length == 3 && sub.equals("set") && sender.hasPermission("chiragranks.rank.set")) {
            return Completions.filter(rankIdList(), args[2]);
        }
        return List.of();
    }

    private List<String> rankIdList() {
        List<String> ids = new ArrayList<>();
        for (Rank rank : plugin.ranks().getRanks()) {
            ids.add(rank.id());
        }
        return ids;
    }
}
