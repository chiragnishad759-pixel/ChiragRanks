package com.chirag.chiragranks.utils;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.trim.ArmorTrim;
import org.bukkit.inventory.meta.trim.TrimMaterial;
import org.bukkit.inventory.meta.trim.TrimPattern;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;

/** Builds ItemStacks from kits.yml item maps, validating enchantments. */
public final class ItemParser {

    private ItemParser() {
    }

    public static NamespacedKey key(Object value) {
        if (value == null) {
            return null;
        }
        try {
            return NamespacedKey.minecraft(String.valueOf(value).trim().toLowerCase(Locale.ROOT).replace(' ', '_'));
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    public static int number(Object value, int fallback) {
        return value instanceof Number n ? n.intValue() : fallback;
    }

    public static ItemStack parse(Map<?, ?> raw, boolean allowUnsafe, Logger log, String context) {
        Object materialName = raw.get("material");
        Material material = materialName == null ? null : Material.matchMaterial(String.valueOf(materialName));
        if (material == null || material.isAir() || !material.isItem()) {
            log.warning("[" + context + "] Unknown or invalid material '" + materialName + "' - item skipped.");
            return null;
        }

        int amount = Math.max(1, Math.min(number(raw.get("amount"), 1), material.getMaxStackSize()));
        ItemStack item = new ItemStack(material, amount);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }

        Object name = raw.get("name");
        if (name != null) {
            meta.displayName(Text.item(String.valueOf(name)));
        }

        if (raw.get("lore") instanceof List<?> loreList) {
            List<Component> lore = new ArrayList<>();
            for (Object line : loreList) {
                lore.add(Text.item(String.valueOf(line)));
            }
            meta.lore(lore);
        }

        if (raw.get("enchantments") instanceof Map<?, ?> enchants) {
            for (Map.Entry<?, ?> entry : enchants.entrySet()) {
                NamespacedKey key = key(entry.getKey());
                Enchantment enchantment = key == null ? null : Registry.ENCHANTMENT.get(key);
                if (enchantment == null) {
                    log.warning("[" + context + "] Unknown enchantment '" + entry.getKey() + "' on " + material + " - skipped.");
                    continue;
                }
                int level = number(entry.getValue(), 1);
                if (level < 1) {
                    continue;
                }
                if (!enchantment.canEnchantItem(item)) {
                    log.warning("[" + context + "] " + entry.getKey() + " cannot be applied to " + material + " - skipped.");
                    continue;
                }
                boolean conflict = false;
                for (Enchantment existing : meta.getEnchants().keySet()) {
                    if (existing.conflictsWith(enchantment)) {
                        log.warning("[" + context + "] " + entry.getKey() + " conflicts with an enchantment on "
                                + material + " - skipped.");
                        conflict = true;
                        break;
                    }
                }
                if (conflict) {
                    continue;
                }
                if (!allowUnsafe) {
                    level = Math.min(level, enchantment.getMaxLevel());
                }
                meta.addEnchant(enchantment, level, true);
            }
        }

        if (Boolean.TRUE.equals(raw.get("glow"))) {
            meta.setEnchantmentGlintOverride(true);
        }
        if (Boolean.TRUE.equals(raw.get("unbreakable"))) {
            meta.setUnbreakable(true);
        }

        if (raw.get("trim") instanceof Map<?, ?> trim && meta instanceof ArmorMeta armorMeta) {
            NamespacedKey patternKey = key(trim.get("pattern"));
            NamespacedKey materialKey = key(trim.get("material"));
            TrimPattern pattern = patternKey == null ? null : Registry.TRIM_PATTERN.get(patternKey);
            TrimMaterial trimMaterial = materialKey == null ? null : Registry.TRIM_MATERIAL.get(materialKey);
            if (pattern != null && trimMaterial != null) {
                armorMeta.setTrim(new ArmorTrim(trimMaterial, pattern));
            } else {
                log.warning("[" + context + "] Invalid armor trim on " + material + " - skipped.");
            }
        }

        item.setItemMeta(meta);
        return item;
    }
}
