package com.chirag.chiragranks.utils;

import com.chirag.chiragranks.ChiragRanks;
import com.chirag.chiragranks.storage.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.UUID;

/** Resolves a player name to a UUID without blocking lookups. */
public final class PlayerLookup {

    public record Target(UUID uuid, String name, Player online) {
    }

    private PlayerLookup() {
    }

    public static Target find(ChiragRanks plugin, String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            return new Target(online.getUniqueId(), online.getName(), online);
        }
        PlayerData data = plugin.storage().findByName(name);
        if (data != null) {
            return new Target(data.getUuid(), data.getName(), null);
        }
        OfflinePlayer offline = Bukkit.getOfflinePlayerIfCached(name);
        if (offline != null) {
            return new Target(offline.getUniqueId(), offline.getName() != null ? offline.getName() : name, null);
        }
        return null;
    }
}
