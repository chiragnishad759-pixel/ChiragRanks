package com.chirag.chiragranks.commands;

import com.chirag.chiragranks.ChiragRanks;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;

import java.util.List;

/** /ranks - shows every rank. */
public final class RanksCommand implements TabExecutor {

    private final ChiragRanks plugin;

    public RanksCommand(ChiragRanks plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        RankCommand.sendRankList(plugin, sender);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return List.of();
    }
}
