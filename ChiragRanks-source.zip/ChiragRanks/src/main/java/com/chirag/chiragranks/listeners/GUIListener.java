package com.chirag.chiragranks.listeners;

import com.chirag.chiragranks.ChiragRanks;
import com.chirag.chiragranks.gui.KitGUI;
import com.chirag.chiragranks.kits.Kit;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Handles clicks inside the kit menus. All interaction with those menus is read-only. */
public final class GUIListener implements Listener {

    private final ChiragRanks plugin;

    public GUIListener(ChiragRanks plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        InventoryHolder holder = top.getHolder(false);
        boolean main = holder instanceof KitGUI.MainHolder;
        boolean preview = holder instanceof KitGUI.PreviewHolder;
        if (!main && !preview) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getClickedInventory() != top) {
            return;
        }
        int slot = event.getRawSlot();

        if (holder instanceof KitGUI.MainHolder mainHolder) {
            if (slot == mainHolder.closeSlot()) {
                Bukkit.getScheduler().runTask(plugin, () -> player.closeInventory());
                return;
            }
            String kitId = mainHolder.kitSlots().get(slot);
            if (kitId == null) {
                return;
            }
            Kit kit = plugin.kits().getKit(kitId);
            if (kit == null) {
                return;
            }
            if (event.isRightClick()) {
                Bukkit.getScheduler().runTask(plugin, () -> plugin.gui().openPreview(player, kit));
                return;
            }
            // Locked kits show the required rank; unlocked kits are claimed (same code path as /kit).
            plugin.kits().claimAndNotify(player, kit);
            plugin.gui().populate(player, mainHolder);
        } else if (holder instanceof KitGUI.PreviewHolder previewHolder) {
            if (slot == previewHolder.backSlot()) {
                Bukkit.getScheduler().runTask(plugin, () -> plugin.gui().openMain(player));
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent event) {
        InventoryHolder holder = event.getView().getTopInventory().getHolder(false);
        if (holder instanceof KitGUI.MainHolder || holder instanceof KitGUI.PreviewHolder) {
            event.setCancelled(true);
        }
    }
}
