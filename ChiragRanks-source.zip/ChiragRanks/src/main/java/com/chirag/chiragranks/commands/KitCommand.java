package com.chirag.chiragranks.commands;

import com.chirag.chiragranks.ChiragRanks;
import com.chirag.chiragranks.kits.Kit;
import com.chirag.chiragranks.kits.KitManager;
import com.chirag.chiragranks.utils.Completions;
import com.chirag.chiragranks.utils.Messages;
import com.chirag.chiragranks.utils.PlayerLookup;
import com.chirag.chiragranks.utils.PlayerLookup.Target;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.StringJoiner;

/** /kit, /kit <name>, /kit preview <name>, /kit list, /kit reset <player> <kit|all>. */
public final class KitCommand implements TabExecutor {

    private final ChiragRanks plugin;

    public KitCommand(ChiragRanks plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Messages messages = plugin.messages();

        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                messages.send(sender, "players-only");
                return true;
            }
            plugin.gui().openMain(player);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list":
                sendList(sender);
                return true;
            case "preview":
                return handlePreview(sender, args);
            case "reset":
                return handleReset(sender, args);
            case "help":
                messages.sendLines(sender, "usage-kit");
                return true;
            default:
                return handleClaim(sender, args[0]);
        }
    }

    private boolean handleClaim(CommandSender sender, String kitName) {
        Messages messages = plugin.messages();
        if (!(sender instanceof Player player)) {
            messages.send(sender, "players-only");
            return true;
        }
        Kit kit = plugin.kits().getKit(kitName);
        if (kit == null) {
            messages.send(sender, "kit-not-found",
                    Placeholder.unparsed("kit", kitName), Placeholder.unparsed("kits", kitIds()));
            return true;
        }
        plugin.kits().claimAndNotify(player, kit);
        return true;
    }

    private boolean handlePreview(CommandSender sender, String[] args) {
        Messages messages = plugin.messages();
        if (!(sender instanceof Player player)) {
            messages.send(sender, "players-only");
            return true;
        }
        if (args.length < 2) {
            messages.sendLines(sender, "usage-kit");
            return true;
        }
        Kit kit = plugin.kits().getKit(args[1]);
        if (kit == null) {
            messages.send(sender, "kit-not-found",
                    Placeholder.unparsed("kit", args[1]), Placeholder.unparsed("kits", kitIds()));
            return true;
        }
        plugin.gui().openPreview(player, kit);
        return true;
    }

    private boolean handleReset(CommandSender sender, String[] args) {
        Messages messages = plugin.messages();
        if (!sender.hasPermission("chiragranks.kit.reset")) {
            messages.send(sender, "no-permission");
            return true;
        }
        if (args.length < 3) {
            messages.sendLines(sender, "usage-kit");
            return true;
        }
        Target target = PlayerLookup.find(plugin, args[1]);
        if (target == null) {
            messages.send(sender, "player-not-found", Placeholder.unparsed("player", args[1]));
            return true;
        }
        if (args[2].equalsIgnoreCase("all")) {
            plugin.kits().resetCooldown(target.uuid(), null);
            messages.send(sender, "kit-reset-all", Placeholder.unparsed("player", target.name()));
            return true;
        }
        Kit kit = plugin.kits().getKit(args[2]);
        if (kit == null) {
            messages.send(sender, "kit-not-found",
                    Placeholder.unparsed("kit", args[2]), Placeholder.unparsed("kits", kitIds()));
            return true;
        }
        plugin.kits().resetCooldown(target.uuid(), kit.id());
        messages.send(sender, "kit-reset",
                Placeholder.unparsed("kit", kit.id()), Placeholder.unparsed("player", target.name()));
        return true;
    }

    private void sendList(CommandSender sender) {
        Messages messages = plugin.messages();
        KitManager kits = plugin.kits();
        messages.sendLines(sender, "kit-list-header");
        for (Kit kit : kits.getKits()) {
            Component status;
            if (sender instanceof Player player) {
                if (!kits.canUse(player, kit)) {
                    status = messages.component("kit-status-locked",
                            Placeholder.component("rank", kits.requiredRankComponent(kit)));
                } else {
                    long remaining = kits.remainingFor(player, kit);
                    status = remaining > 0
                            ? messages.component("kit-status-cooldown",
                                    Placeholder.unparsed("time", com.chirag.chiragranks.utils.Text.duration(remaining)))
                            : messages.component("kit-status-ready");
                }
            } else {
                status = messages.component("kit-status-all");
            }
            sender.sendMessage(messages.component("kit-list-entry",
                    Placeholder.component("kit", kit.displayComponent()),
                    Placeholder.component("status", status)));
        }
    }

    private String kitIds() {
        StringJoiner joiner = new StringJoiner(", ");
        for (Kit kit : plugin.kits().getKits()) {
            joiner.add(kit.id());
        }
        return joiner.toString();
    }

    private List<String> kitIdList() {
        List<String> ids = new ArrayList<>();
        for (Kit kit : plugin.kits().getKits()) {
            ids.add(kit.id());
        }
        return ids;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> options = new ArrayList<>(List.of("list", "preview"));
            if (sender.hasPermission("chiragranks.kit.reset")) {
                options.add("reset");
            }
            options.addAll(kitIdList());
            return Completions.filter(options, args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2) {
            if (sub.equals("preview")) {
                return Completions.filter(kitIdList(), args[1]);
            }
            if (sub.equals("reset") && sender.hasPermission("chiragranks.kit.reset")) {
                return Completions.filter(Completions.onlinePlayers(), args[1]);
            }
        }
        if (args.length == 3 && sub.equals("reset") && sender.hasPermission("chiragranks.kit.reset")) {
            List<String> options = new ArrayList<>(kitIdList());
            options.add("all");
            return Completions.filter(options, args[2]);
        }
        return List.of();
    }
}
