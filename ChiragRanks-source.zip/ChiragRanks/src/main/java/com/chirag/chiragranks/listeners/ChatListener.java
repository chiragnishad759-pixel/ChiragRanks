package com.chirag.chiragranks.listeners;

import com.chirag.chiragranks.ChiragRanks;
import com.chirag.chiragranks.ranks.Rank;
import com.chirag.chiragranks.utils.Text;
import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

/** Formats chat with rank prefix, gradient name and rank chat color. */
public final class ChatListener implements Listener {

    private static final String DEFAULT_FORMAT = "<prefix> <name><dark_gray> »</dark_gray> <message>";

    private final ChiragRanks plugin;

    public ChatListener(ChiragRanks plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!plugin.getConfig().getBoolean("chat.enabled", true)) {
            return;
        }
        Player player = event.getPlayer();
        Rank rank = plugin.ranks().getPlayerRank(player.getUniqueId());
        String format = plugin.getConfig().getString("chat.format", DEFAULT_FORMAT);

        event.renderer(ChatRenderer.viewerUnaware((source, sourceDisplayName, message) -> {
            Component coloured = message.colorIfAbsent(rank.chatColor());
            return Text.parse(format,
                    Placeholder.component("prefix", rank.prefixComponent()),
                    Placeholder.component("name", rank.formatName(source.getName())),
                    Placeholder.component("message", coloured),
                    Placeholder.component("rank_display", rank.displayComponent()),
                    Placeholder.unparsed("rank", rank.id()));
        }));
    }
}
