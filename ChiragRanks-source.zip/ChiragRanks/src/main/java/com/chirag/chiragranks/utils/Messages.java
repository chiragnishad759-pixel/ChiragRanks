package com.chirag.chiragranks.utils;

import com.chirag.chiragranks.ChiragRanks;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** Loads messages.yml (with the bundled file as fallback for missing keys) and sends them. */
public final class Messages {

    private final ChiragRanks plugin;
    private YamlConfiguration config = new YamlConfiguration();

    public Messages(ChiragRanks plugin) {
        this.plugin = plugin;
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        try (InputStream in = plugin.getResource("messages.yml")) {
            if (in != null) {
                yaml.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)));
            }
        } catch (Exception ex) {
            plugin.getLogger().warning("Could not read bundled messages.yml: " + ex.getMessage());
        }
        this.config = yaml;
    }

    public String raw(String key) {
        String value = config.getString(key);
        return value != null ? value : "<red>Missing message: " + key;
    }

    public Component component(String key, TagResolver... resolvers) {
        return Text.parse(raw(key), resolvers);
    }

    /** Component for item names/lore (no italics). */
    public Component item(String key, TagResolver... resolvers) {
        return Text.item(raw(key), resolvers);
    }

    public void send(CommandSender target, String key, TagResolver... resolvers) {
        target.sendMessage(Text.parse(raw("prefix") + raw(key), resolvers));
    }

    public List<String> list(String key) {
        return config.getStringList(key);
    }

    public void sendLines(CommandSender target, String key, TagResolver... resolvers) {
        for (String line : list(key)) {
            target.sendMessage(Text.parse(line, resolvers));
        }
    }
}
