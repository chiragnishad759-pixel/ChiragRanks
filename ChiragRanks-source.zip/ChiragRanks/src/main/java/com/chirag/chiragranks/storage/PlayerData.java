package com.chirag.chiragranks.storage;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Persistent data for a single player. */
public final class PlayerData {

    private final UUID uuid;
    private volatile String name;
    private volatile String rank;
    private volatile String assignedBy;
    private volatile long assignedAt;
    /** kit id -> epoch millis when the cooldown expires. */
    private final Map<String, Long> cooldowns = new ConcurrentHashMap<>();

    public PlayerData(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getAssignedBy() {
        return assignedBy;
    }

    public void setAssignedBy(String assignedBy) {
        this.assignedBy = assignedBy;
    }

    public long getAssignedAt() {
        return assignedAt;
    }

    public void setAssignedAt(long assignedAt) {
        this.assignedAt = assignedAt;
    }

    public Map<String, Long> getCooldowns() {
        return cooldowns;
    }
}
