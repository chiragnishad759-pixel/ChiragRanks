# ChiragRanks

All-in-one Ranks + Kits plugin for Paper (1.21+), Java 21.

## Build

Option A - GitHub (no tools needed)
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
   If the web uploader skips `.github`, use *Add file > Create new file* and type
   `.github/workflows/build.yml`, then paste the contents of that file.
2. Open the **Actions** tab > latest "Build ChiragRanks" run > download the **ChiragRanks** artifact (contains `ChiragRanks.jar`).

Option B - locally: install JDK 21 + Maven, then run `mvn clean package`. The JAR is `target/ChiragRanks.jar`.

## Install
Drop `ChiragRanks.jar` into `plugins/`, start the server, edit `plugins/ChiragRanks/*.yml`, then `/rank reload`.

## Commands
- `/rank <player> <rank>`, `/rank set <player> <rank>`, `/rank remove <player>`, `/rank info <player>`, `/rank list`, `/rank reload`, `/ranks`
- `/kit`, `/kit <name>`, `/kit preview <name>`, `/kit list`, `/kit reset <player> <kit|all>`

## Permissions
`chiragranks.use` (default true), `chiragranks.admin` (op), `chiragranks.rank.set|remove|info|list`, `chiragranks.reload`,
`chiragranks.kit.<starter|vip|mvp|legendary|media|elite|cosmic>`, `chiragranks.kit.*`, `chiragranks.kit.reset`, `chiragranks.bypass.cooldown`.
Players inherit the permissions of every rank at or below their own priority (see `ranks.yml`).
A kit can be claimed if the player's rank priority >= the kit's required rank, or they hold the kit permission.

## Data
`plugins/ChiragRanks/data.yml` stores UUID, name, rank assignment (who/when) and kit cooldowns (expiry timestamps).
